package com.frontdash.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FrontdashBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
