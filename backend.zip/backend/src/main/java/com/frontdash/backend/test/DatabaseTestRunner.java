package com.frontdash.backend.test;

import com.frontdash.backend.entity.*;
import com.frontdash.backend.repository.*;
import com.frontdash.backend.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.sql.Time;
import java.time.LocalDateTime;
import java.util.*;

@Component
public class DatabaseTestRunner implements CommandLineRunner {

    @Autowired
    private StaffRepository staffRepository;

    @Autowired
    private RestaurantRepository restaurantRepository;

    @Autowired
    private RestaurantHoursRepository restaurantHoursRepository;

    @Autowired
    private MenuItemRepository menuItemRepository;

    @Autowired
    private WithdrawRepository withdrawRepository;

    @Autowired
    private RestaurantService restaurantService;

    @Autowired
    private MenuService menuService;

    @Autowired
    private WithdrawalService withdrawalService;

    // Test data storage for cleanup
    private final List<String> testStaffIds = new ArrayList<>();
    private final List<String> testRestaurantIds = new ArrayList<>();
    private final List<String> testMenuItemIds = new ArrayList<>();
    private final List<Long> testHoursIds = new ArrayList<>();

    @Override
    public void run(String... args) throws Exception {
        System.out.println("\n" + "=".repeat(80));
        System.out.println("🚀 STARTING COMPREHENSIVE DATABASE TEST");
        System.out.println("=".repeat(80));

        try {
            // Record initial state
            Map<String, Long> initialCounts = recordInitialCounts();
            
            // Run all tests
            testStaffOperations();
            testRestaurantOperations();
            testMenuOperations();
            testWithdrawalOperations();
            testComplexRelationships();
            
            // Cleanup and verify
            cleanupTestData();
            verifyFinalState(initialCounts);
            
            System.out.println("\n" + "🎉 ALL TESTS PASSED SUCCESSFULLY!");
            
        } catch (Exception e) {
            System.err.println("\n❌ TEST FAILED: " + e.getMessage());
            e.printStackTrace();
            // Attempt cleanup even if tests fail
            emergencyCleanup();
        }
    }

    private Map<String, Long> recordInitialCounts() {
        System.out.println("\n📊 RECORDING INITIAL DATABASE STATE:");
        Map<String, Long> counts = new HashMap<>();
        
        counts.put("staff", staffRepository.count());
        counts.put("restaurants", restaurantRepository.count());
        counts.put("restaurant_hours", restaurantHoursRepository.count());
        counts.put("menu_items", menuItemRepository.count());
        counts.put("withdrawals", withdrawRepository.count());
        
        counts.forEach((table, count) -> 
            System.out.println("   " + table + ": " + count + " records"));
        
        return counts;
    }

    private void testStaffOperations() {
        System.out.println("\n👥 TESTING STAFF OPERATIONS:");
        
        // Create test staff
        Staff testStaff = new Staff();
        testStaff.setStaffId("test-staff-001");
        testStaff.setRoleId(1);
        testStaff.setFirstName("Test");
        testStaff.setLastName("Manager");
        testStaff.setEmail("test.manager@frontdash.com");
        testStaff.setPhone("555-0101");
        
        Staff savedStaff = staffRepository.save(testStaff);
        testStaffIds.add(savedStaff.getStaffId());
        
        System.out.println("✅ Created staff: " + savedStaff.getFirstName() + " " + savedStaff.getLastName());
        
        // Verify staff was saved
        Optional<Staff> foundStaff = staffRepository.findById(savedStaff.getStaffId());
        if (foundStaff.isPresent()) {
            System.out.println("✅ Verified staff retrieval: " + foundStaff.get().getEmail());
        } else {
            throw new RuntimeException("Staff retrieval failed!");
        }
    }

    private void testRestaurantOperations() {
        System.out.println("\n🏪 TESTING RESTAURANT OPERATIONS:");
        
        if (testStaffIds.isEmpty()) {
            throw new RuntimeException("Cannot test restaurants without staff!");
        }
        
        String staffId = testStaffIds.get(0);
        
        // Create test restaurant
        Restaurant testRestaurant = new Restaurant();
        testRestaurant.setRestaurantId("test-rest-001");
        testRestaurant.setOwnerId(staffId);
        testRestaurant.setRestaurantName("Test Delight Restaurant");
        testRestaurant.setCuisineType("American");
        testRestaurant.setEmail("test@delight.com");
        testRestaurant.setPhone("555-0202");
        testRestaurant.setHumanContactName("Test Owner");
        testRestaurant.setStreet("123 Test Street");
        testRestaurant.setCity("Testville");
        testRestaurant.setState("TS");
        testRestaurant.setZip("12345");
        testRestaurant.setForceClosed(false);
        
        Restaurant savedRestaurant = restaurantRepository.save(testRestaurant);
        testRestaurantIds.add(savedRestaurant.getRestaurantId());
        
        System.out.println("✅ Created restaurant: " + savedRestaurant.getRestaurantName());
        
        // Test operating hours
        testOperatingHours(savedRestaurant.getRestaurantId());
        
        // Test contact info update
        restaurantService.updateContactInfo(
            savedRestaurant.getRestaurantId(),
            "555-0203", 
            "updated@delight.com", 
            "Updated Contact"
        );
        System.out.println("✅ Updated restaurant contact info");
        
        // Verify restaurant retrieval
        Optional<Restaurant> foundRestaurant = restaurantRepository.findById(savedRestaurant.getRestaurantId());
        if (foundRestaurant.isPresent() && "updated@delight.com".equals(foundRestaurant.get().getEmail())) {
            System.out.println("✅ Verified restaurant update: " + foundRestaurant.get().getEmail());
        } else {
            throw new RuntimeException("Restaurant update verification failed!");
        }
    }

    private void testOperatingHours(String restaurantId) {
        System.out.println("   ⏰ TESTING OPERATING HOURS:");
        
        // Create operating hours for each day
        String[] days = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
        
        for (int i = 0; i < days.length; i++) {
            RestaurantHours hours = new RestaurantHours();
            hours.setRestaurant(restaurantRepository.findById(restaurantId).orElseThrow());
            hours.setWeekday(i);
            
            if (i == 0) { // Sunday - closed
                hours.setIsClosed(true);
            } else {
                hours.setOpensAt(Time.valueOf("09:00:00"));
                hours.setClosesAt(Time.valueOf("21:00:00"));
                hours.setIsClosed(false);
            }
            
            RestaurantHours savedHours = restaurantHoursRepository.save(hours);
            testHoursIds.add(savedHours.getHoursId());
            
            System.out.println("     ✅ Created hours for " + days[i] + ": " + 
                (savedHours.getIsClosed() ? "CLOSED" : savedHours.getOpensAt() + " to " + savedHours.getClosesAt()));
        }
        
        // Verify hours were saved
        List<RestaurantHours> allHours = restaurantHoursRepository.findByRestaurantId(restaurantId);
        System.out.println("   ✅ Verified " + allHours.size() + " operating hours records");
    }

    private void testMenuOperations() {
        System.out.println("\n🍽️ TESTING MENU OPERATIONS:");
        
        if (testRestaurantIds.isEmpty()) {
            throw new RuntimeException("Cannot test menu without restaurant!");
        }
        
        String restaurantId = testRestaurantIds.get(0);
        
        // Create test menu items
        MenuItem item1 = new MenuItem();
        item1.setMenuItemId("test-menu-001");
        item1.setRestaurant(restaurantRepository.findById(restaurantId).orElseThrow());
        item1.setCategory("Appetizers");
        item1.setFoodName("Test Bruschetta");
        item1.setFoodDescription("Fresh tomatoes and basil on toasted bread");
        item1.setPrice(new BigDecimal("8.99"));
        item1.setIsAvailable(true);
        item1.setAllergens("Gluten");
        
        MenuItem item2 = new MenuItem();
        item2.setMenuItemId("test-menu-002");
        item2.setRestaurant(restaurantRepository.findById(restaurantId).orElseThrow());
        item2.setCategory("Main Course");
        item2.setFoodName("Test Pasta");
        item2.setFoodDescription("Creamy pasta with seasonal vegetables");
        item2.setPrice(new BigDecimal("14.99"));
        item1.setIsAvailable(false);
        item2.setAllergens("Dairy, Gluten");
        
        MenuItem savedItem1 = menuItemRepository.save(item1);
        MenuItem savedItem2 = menuItemRepository.save(item2);
        testMenuItemIds.add(savedItem1.getMenuItemId());
        testMenuItemIds.add(savedItem2.getMenuItemId());
        
        System.out.println("✅ Created menu items: " + savedItem1.getFoodName() + " and " + savedItem2.getFoodName());
        
        // Test menu retrieval
        List<MenuItem> menuItems = menuService.getMenuByRestaurant(restaurantId);
        System.out.println("✅ Retrieved " + menuItems.size() + " menu items for restaurant");
        
        // Test availability toggle
        menuService.toggleAvailability(savedItem1.getMenuItemId());
        System.out.println("✅ Toggled menu item availability");

        // Verify menu item update
        Optional<MenuItem> updatedItem = menuItemRepository.findById(savedItem1.getMenuItemId());
        if (updatedItem.isPresent()) {
            System.out.println("✅ Verified menu item availability update - new status: " + updatedItem.get().getIsAvailable());
        } else {
            throw new RuntimeException("Menu item update verification failed!");
        }
    }

    private void testWithdrawalOperations() {
        System.out.println("\n📝 TESTING WITHDRAWAL OPERATIONS:");
        
        if (testRestaurantIds.isEmpty()) {
            throw new RuntimeException("Cannot test withdrawals without restaurant!");
        }
        
        String restaurantId = testRestaurantIds.get(0);
        
        // Test withdrawal request
        Withdraw withdrawal = withdrawalService.requestWithdrawal(
            restaurantId, 
            "Test withdrawal request for demonstration purposes"
        );
        
        System.out.println("✅ Created withdrawal request with status: " + withdrawal.getWithdrawStatus());
        
        // Test withdrawal status check
        String status = withdrawalService.getWithdrawalStatus(restaurantId);
        System.out.println("✅ Verified withdrawal status: " + status);
        
        // Test pending request check
        boolean hasPending = withdrawalService.hasPendingRequest(restaurantId);
        System.out.println("✅ Verified pending request exists: " + hasPending);
        
        // Test withdrawal cancellation
        withdrawalService.cancelWithdrawalRequest(restaurantId);
        System.out.println("✅ Cancelled withdrawal request");
        
        // Verify cancellation
        String finalStatus = withdrawalService.getWithdrawalStatus(restaurantId);
        if ("none".equals(finalStatus)) {
            System.out.println("✅ Verified withdrawal cancellation");
        } else {
            throw new RuntimeException("Withdrawal cancellation verification failed!");
        }
    }

    private void testComplexRelationships() {
        System.out.println("\n🔗 TESTING COMPLEX RELATIONSHIPS:");
        
        if (testRestaurantIds.isEmpty()) return;
        
        String restaurantId = testRestaurantIds.get(0);
        
        // Test restaurant with operating hours
        Optional<Restaurant> restaurantWithHours = restaurantService.getRestaurantWithOperatingHours(restaurantId);
        if (restaurantWithHours.isPresent()) {
            Restaurant restaurant = restaurantWithHours.get();
            System.out.println("✅ Retrieved restaurant '" + restaurant.getRestaurantName() + 
                "' with " + restaurant.getOperatingHours().size() + " operating hours");
        }
        
        // Test restaurant with menu items
        List<MenuItem> menuItems = menuService.getMenuByRestaurant(restaurantId);
        System.out.println("✅ Verified restaurant has " + menuItems.size() + " menu items");
        
        // Test service layer integration
        try {
            restaurantService.saveAllOperatingHours(restaurantId, 
                restaurantHoursRepository.findByRestaurantId(restaurantId));
            System.out.println("✅ Verified service layer operating hours update");
        } catch (Exception e) {
            throw new RuntimeException("Service layer integration test failed: " + e.getMessage());
        }
    }

    private void cleanupTestData() {
        System.out.println("\n🧹 CLEANING UP TEST DATA:");
        
        // Delete in reverse order to respect foreign key constraints
        System.out.println("   Deleting " + testMenuItemIds.size() + " test menu items...");
        testMenuItemIds.forEach(menuItemRepository::deleteById);
        
        System.out.println("   Deleting " + testHoursIds.size() + " test operating hours...");
        testHoursIds.forEach(restaurantHoursRepository::deleteById);
        
        System.out.println("   Deleting " + testRestaurantIds.size() + " test restaurants...");
        testRestaurantIds.forEach(restaurantRepository::deleteById);
        
        System.out.println("   Deleting " + testStaffIds.size() + " test staff...");
        testStaffIds.forEach(staffRepository::deleteById);
        
        System.out.println("✅ All test data cleaned up");
    }

    private void verifyFinalState(Map<String, Long> initialCounts) {
        System.out.println("\n🔍 VERIFYING FINAL DATABASE STATE:");
        
        Map<String, Long> finalCounts = new HashMap<>();
        finalCounts.put("staff", staffRepository.count());
        finalCounts.put("restaurants", restaurantRepository.count());
        finalCounts.put("restaurant_hours", restaurantHoursRepository.count());
        finalCounts.put("menu_items", menuItemRepository.count());
        finalCounts.put("withdrawals", withdrawRepository.count());
        
        boolean allMatch = true;
        
        for (String table : initialCounts.keySet()) {
            long initial = initialCounts.get(table);
            long finalCount = finalCounts.get(table);
            String status = initial == finalCount ? "✅" : "❌";
            
            System.out.println("   " + table + ": " + initial + " → " + finalCount + " " + status);
            
            if (initial != finalCount) {
                allMatch = false;
            }
        }
        
        if (!allMatch) {
            throw new RuntimeException("Database state verification failed! Initial and final counts do not match.");
        }
        
        System.out.println("✅ Database state verification passed - all counts match initial state");
    }

    private void emergencyCleanup() {
        System.out.println("\n🚨 PERFORMING EMERGENCY CLEANUP:");
        try {
            cleanupTestData();
        } catch (Exception e) {
            System.err.println("Emergency cleanup failed: " + e.getMessage());
        }
    }
}